# -*- coding: utf-8 -*-
"""
Created on Mon Aug 28 17:08:28 2023

@author: Admin
"""

import cv2

# read the input image
image = cv2.imread('4.jpg',0)

# define the alpha and beta


# call convertScaleAbs function
adjusted = cv2.convertScaleAbs(image, 0.5,3)

# display the output image
cv2.imshow('original',image)
cv2.imshow('adjusted', adjusted)
cv2.imwrite("Image4"+'.jpg', adjusted)
cv2.waitKey()
cv2.destroyAllWindows()
