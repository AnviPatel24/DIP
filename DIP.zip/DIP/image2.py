# -*- coding: utf-8 -*-
"""
Created on Mon Aug 28 17:04:20 2023

@author: Admin
"""

import cv2
import numpy as np
import matplotlib.pyplot as plt

image1=cv2.imread("2.png",0)
imagesize=cv2.resize(image1,(500,333))

histgoutput=cv2.calcHist([imagesize],[0],None,[256],[0,256])
plt.plot(histgoutput)
plt.show()
image13=cv2.equalizeHist(imagesize)
histg=cv2.calcHist([image13],[0],None,[256],[0,256])
plt.plot(histg)
plt.show()
#cv2.imshow("Equalize",image12)

cv2.imshow("Original Image",imagesize)
cv2.imshow("Equalize",image13)
cv2.imwrite("Image2"+'.jpg', image13)
cv2.waitKey(0)
cv2.destroyAllWindows()
