# -*- coding: utf-8 -*-
"""
Created on Mon Aug 28 17:53:48 2023

@author: Admin
"""
import cv2
import numpy as np


def gammaCorrection(src, gamma):
    invGamma = 1 / gamma

    table = [((i / 255) ** invGamma) * 255 for i in range(256)]
    table = np.array(table, np.uint8)

    return cv2.LUT(src, table)


img = cv2.imread('3.jpg')
gammaImg = gammaCorrection(img, 1.7)


cv2.imshow('Original image', img)
cv2.imshow('Gamma corrected image', gammaImg)
cv2.imwrite("Q31"+'.jpg', gammaImg)
cv2.waitKey(0)
cv2.destroyAllWindows()
