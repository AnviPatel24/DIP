# -*- coding: utf-8 -*-
"""
Created on Mon Aug 28 17:17:07 2023 

@author: Admin
"""
import cv2
import numpy as np
import matplotlib.pyplot as plt
# Load the image
img = cv2.imread('4.jpg',0)
# Find width and height of image
row, column = img.shape
# Create an zeros array to store the sliced image
img1 = np.zeros((row,column),dtype = 'uint8')
 
# Specify the min and max range
min_range = 10
max_range = 80
 
# Loop over the input image and if pixel value lies in desired range set it to 255 otherwise set it to 0.
for i in range(row):
    for j in range(column):
        if img[i,j]>min_range and img[i,j]<max_range:
            img1[i,j] = 255
        else:
            img1[i,j] = 0
            
histg=cv2.calcHist([img],[0],None,[256],[0,256])
plt.plot(histg)
plt.show()          
# Display the image
cv2.imshow('original',img)
cv2.imshow('sliced image', img1)
cv2.imwrite("Q2"+'.jpg', img1)
cv2.waitKey(0) 