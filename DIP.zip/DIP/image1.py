# -*- coding: utf-8 -*-
"""
Created on Mon Aug 28 16:54:59 2023

@author: Admin
"""

import cv2
import numpy as np
import matplotlib.pyplot as plt

image1=cv2.imread("1.jpg",0)

histg=cv2.calcHist([image1],[0],None,[256],[0,256])
plt.plot(histg)
plt.show()



minval=np.min(image1)
maxval=np.max(image1)
#image13=175+((image1+minval)*(80/(maxval-minval))).astype(np.uint8)
image13=cv2.normalize(image1,None,0.7,110,cv2.NORM_MINMAX)
histgoutput=cv2.calcHist([image13],[0],None,[256],[0,256])
plt.plot(histgoutput)
plt.show()
cv2.imshow("Original Image",image1)
cv2.imshow("Normalize",image13)
cv2.imwrite("Image1"+'.jpg', image13)
cv2.waitKey(0)
cv2.destroyAllWindows()

