# -*- coding: utf-8 -*-
"""
Created on Mon Aug 28 18:37:04 2023

@author: Admin
"""

import cv2

# Load the grayscale image
image=cv2.imread("5.jpg",0)
cv2.imshow("Grayscale Image",image)
height, width = image.shape

# Iterate through each pixel using nested loops
for y in range(height):
    for x in range(width):
        pixel_value = image[y, x]
        if(pixel_value>=128):
           image[y,x]=255
        else:
           image[y,x]=0
cv2.imshow("Binary Image",image) 
cv2.imwrite("Q4"+'.jpg',image)       
cv2.waitKey(0)
cv2.destroyAllWindows()
